package com.cognizant.Main.enums;

public enum OrderStatus {
	PENDING, SUBMITTED
}
