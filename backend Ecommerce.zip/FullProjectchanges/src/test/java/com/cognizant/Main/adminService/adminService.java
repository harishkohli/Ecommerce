package com.cognizant.Main.adminService;
import com.cognizant.Main.dto.CategoryDTO;
import com.cognizant.Main.dto.OrderDTO;
import com.cognizant.Main.dto.ProductDTO;
import com.cognizant.Main.entities.Category;
import com.cognizant.Main.entities.Order;
import com.cognizant.Main.entities.Product;
import com.cognizant.Main.enums.OrderStatus;
import com.cognizant.Main.repository.CategoryRepository;
import com.cognizant.Main.repository.OrderRepository;
import com.cognizant.Main.repository.ProductRepository;
import com.cognizant.Main.service.admin.AdminServiceImpl;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class adminService {

    @Mock
    private CategoryRepository categoryRepository;

    @Mock
    private ProductRepository productRepository;

    @Mock
    private OrderRepository orderRepository;

    @InjectMocks
    private AdminServiceImpl adminService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetAllCategories() {
        Category category1 = new Category();
        category1.setName("Electronics");
        Category category2 = new Category();
        category2.setName("Books");

        when(categoryRepository.findAll()).thenReturn(Arrays.asList(category1, category2));

        List<CategoryDTO> categories = adminService.getAllCategories();

        assertEquals(2, categories.size());
        verify(categoryRepository, times(1)).findAll();
    }

    @Test
    void testGetAllProducts() {
        Product product1 = new Product();
        product1.setName("Laptop");
        Product product2 = new Product();
        product2.setName("Book");

        when(productRepository.findAll()).thenReturn(Arrays.asList(product1, product2));

        List<ProductDTO> products = adminService.getAllProducts();

        assertEquals(2, products.size());
        verify(productRepository, times(1)).findAll();
    }

    @Test
    void testGetProductById() {
        Product product = new Product();
        product.setId(1L);
        product.setName("Laptop");

        when(productRepository.findById(1L)).thenReturn(Optional.of(product));

        ProductDTO productDTO = adminService.getProductById(1L);

        assertNotNull(productDTO);
        assertEquals("Laptop", productDTO.getName());
        verify(productRepository, times(1)).findById(1L);
    }

    @Test
    void testGetAllOrders() {
        Order order1 = new Order();
        order1.setOrderStatus(OrderStatus.SUBMITTED);
        Order order2 = new Order();
        order2.setOrderStatus(OrderStatus.SUBMITTED);

        when(orderRepository.findAllByOrderStatus(OrderStatus.SUBMITTED)).thenReturn(Arrays.asList(order1, order2));

        List<OrderDTO> orders = adminService.getAllOrders();

        assertEquals(2, orders.size());
        verify(orderRepository, times(1)).findAllByOrderStatus(OrderStatus.SUBMITTED);
    }
}
