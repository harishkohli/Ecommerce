export const environment={
    BASIC_URL:"http://localhost:8080/"
    
}