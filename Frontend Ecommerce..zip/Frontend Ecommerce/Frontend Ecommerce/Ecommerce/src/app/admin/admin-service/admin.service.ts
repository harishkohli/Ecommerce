import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { LocalStorageService } from '../../services/storage-service/local-storage.service';

@Injectable({
  providedIn: 'root'
})
export class AdminService {
  private baseUrl = 'http://localhost:8080/api/admin';

  constructor(private http: HttpClient, private localStorageService: LocalStorageService) { }

  createAuthorizationHeader(): HttpHeaders {
    const token = this.localStorageService.getToken();
    return new HttpHeaders().set('Authorization', `Bearer ${token}`);
  }

  postCategory(category: any, options: { headers: HttpHeaders }): Observable<any> {
    return this.http.post(`${this.baseUrl}/category`, category, options);
  }

  getAllCategories(): Observable<any> {
    const headers = this.createAuthorizationHeader();
    return this.http.get<[]>(`${this.baseUrl}/categories`, { headers });
  }

  postProduct(productDTO: FormData, p0: { headers: HttpHeaders; }): Observable<any> {
    const categoryId = productDTO.get('categoryId');
    const headers = this.createAuthorizationHeader();
    return this.http.post(`${this.baseUrl}/product/${categoryId}`, productDTO, { headers });
  }

  getAllProducts(): Observable<any> {
    const headers = this.createAuthorizationHeader();
    return this.http.get<[]>(`${this.baseUrl}/products`, { headers });
  }

  deleteproduct(id: number): Observable<any> {
    const headers = this.createAuthorizationHeader();
    return this.http.delete<[]>(`${this.baseUrl}/product/${id}`, { headers });
  }

  getproductById(id: number): Observable<any> {
    const headers = this.createAuthorizationHeader();
    return this.http.get<[]>(`${this.baseUrl}/product/${id}`, { headers });
  }

  updateProduct(id: number, formData: FormData): Observable<any> {
    const token = this.localStorageService.getToken();
     const headers = this.createAuthorizationHeader();
    return this.http.put(`${this.baseUrl}/${formData.get('categoryId')}/product/${id}`, formData, { headers });
  }

}
