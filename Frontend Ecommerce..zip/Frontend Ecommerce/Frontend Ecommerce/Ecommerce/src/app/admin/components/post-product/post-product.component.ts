import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NzNotificationModule, NzNotificationService } from 'ng-zorro-antd/notification';
import { AdminService } from '../../admin-service/admin.service';
import { LocalStorageService } from '../../../services/storage-service/local-storage.service';
import { HttpHeaders } from '@angular/common/http';
import { NzLayoutModule } from 'ng-zorro-antd/layout';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { CommonModule } from '@angular/common';
import { NzSpinModule } from 'ng-zorro-antd/spin';
import { NzFormModule } from 'ng-zorro-antd/form';
import { NzInputModule } from 'ng-zorro-antd/input';
import { NzMenuModule } from 'ng-zorro-antd/menu';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { ReactiveFormsModule } from '@angular/forms';
import { NzUploadModule, NzUploadFile } from 'ng-zorro-antd/upload';

@Component({
  selector: 'app-post-product',
  templateUrl: './post-product.component.html',
  styleUrls: ['./post-product.component.css'],
  imports: [
    CommonModule,
    NzLayoutModule,
    NzButtonModule,
    NzSpinModule,
    NzFormModule,
    NzInputModule,
    ReactiveFormsModule,
    NzNotificationModule,
    NzMenuModule,
    NzIconModule,
    NzUploadModule
  ]
})
export class PostProductComponent implements OnInit {
  navbarOpen = false;
  isSpinning: boolean = false;
  categories: any[] = [];
  selectedFile: NzUploadFile | null = null;
  postProductForm!: FormGroup;

  constructor(
    private router: Router,
    private localStorageService: LocalStorageService,
    private adminService: AdminService,
    private fb: FormBuilder,
    private notification: NzNotificationService
  ) {}

  ngOnInit() {
    this.postProductForm = this.fb.group({
      categoryId: [null, Validators.required],
      name: [null, Validators.required],
      price: [null, Validators.required],
      description: [null, Validators.required],
      images: [null]
    });
    this.getAllCategories();
  }

  getAllCategories() {
    this.adminService.getAllCategories().subscribe(
      (res: any[]) => {
        console.log(res);
        this.categories = res;
      },
      (error: any) => {
        console.error("Failed to fetch categories", error);
      }
    );
  }

  beforeUpload = (file: NzUploadFile, fileList: NzUploadFile[]): boolean => {
    console.log('Selected file:', file);
    this.selectedFile = file;
    return false; // Prevent auto upload
  }

  postProduct() {
    if (this.postProductForm.invalid) {
      console.log("Form is invalid");
      return;
    }
    if (!this.selectedFile) {
      console.error("No file selected.");
      return;
    }
    const productDTO: FormData = new FormData();
    productDTO.append("image", this.selectedFile as any);
    productDTO.append("name", this.postProductForm.get("name")!.value);
    productDTO.append("price", this.postProductForm.get("price")!.value);
    productDTO.append("description", this.postProductForm.get("description")!.value);
    productDTO.append("categoryId", this.postProductForm.get("categoryId")!.value.toString());

    const token = this.localStorageService.getToken();
    const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);
    this.isSpinning = true;
    console.log("Sending request with data:", productDTO);
    this.adminService.postProduct(productDTO, { headers }).subscribe(
      (res: any) => {
        console.log("Response received:", res);
        alert("Product posted Successfully");
        this.router.navigate(['/admin/dashboard']);
        
        this.notification.success('SUCCESS', 'Product posted successfully');
        this.isSpinning = false;
      },
      (error: any) => {
        console.error("Failed to post product:", error);
        this.notification.error('ERROR', 'Failed to post product');
        this.isSpinning = false;
      }
    );
  }

  navigateToAdminDashboard() {
    this.router.navigate(['/admin/dashboard']);
  }

  navigateToAdminCategory() {
    this.router.navigate(['/admin/category']);
  }

  logout() {
    this.localStorageService.signOut();
    alert("Logout successfully");
    this.router.navigateByUrl("/login");
  }

  navigateToProduct() {
    this.router.navigate(['/admin/product']);
  }
}
