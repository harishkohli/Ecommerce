import { Component, OnInit } from '@angular/core';
import { LocalStorageService } from '../../../services/storage-service/local-storage.service';
import { Router } from '@angular/router'; // Import Router
import { NzLayoutModule } from 'ng-zorro-antd/layout'; // Import Layout module
import { NzButtonModule } from 'ng-zorro-antd/button'; // Import Button module
import { CommonModule } from '@angular/common'; // Import CommonModule
import { AdminService } from '../../admin-service/admin.service';

interface Product {
  id: number;
  name: string;            // Add name property
  description: string;     // Add description property
  price: number;           // Add price property
  categoryName: string;    // Add categoryName property
  processedImage: string;
  returnedImage: string;
}

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
  standalone: true,
  imports: [
    CommonModule,
    NzLayoutModule,
    NzButtonModule,
  ]
})
export class DashboardComponent implements OnInit {

  navbarOpen = false;
  isSpinning: boolean = false; // Initialize isSpinning properly
  large: string = 'large'; // Initialize large properly

  products: Product[] = []; // Define the type for the products array

  constructor(
    private router: Router, 
    private localStorageService: LocalStorageService,
    private adminService: AdminService
  ) {}

  navigateToAdminDashboard() {
    this.router.navigate(['/admin/dashboard']);
  }

  navigateToAdminCategory() {
    this.router.navigate(['/admin/category']);
  }

  navigateToProduct() {
    this.router.navigate(['/admin/product']);
  }

  logout() {
    this.localStorageService.signOut();
    alert("Logout successfully");
    this.router.navigateByUrl("/login");
  }

  ngOnInit() {
    this.getAllProducts();
  }

  getAllProducts() {
    this.adminService.getAllProducts().subscribe((res: Product[]) => {
      console.log(res); // Should be an array of products
      res.forEach((element: Product) => {
        element.processedImage = "data:image/jpeg;base64," + element.returnedImage;
        this.products.push(element);
      });
    });
  }

  deleteProduct(id: number) {
    console.log('Product ID:', id);
    this.adminService.deleteproduct(id).subscribe((res) => {
      console.log(res);
      this.getAllProducts();
    });
    this.router.navigate(['/admin/dashboard']);
  }

  updateproduct(id1: number) {
    console.log("updating product is is "+id1);
    this.router.navigate([`/admin/product/${id1}`]);
  }

  


}
