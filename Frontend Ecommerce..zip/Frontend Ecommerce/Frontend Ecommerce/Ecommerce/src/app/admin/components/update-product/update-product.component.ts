import { Component, OnInit } from '@angular/core';
import { AdminService } from '../../admin-service/admin.service';
import { ActivatedRoute, Router } from '@angular/router';
import { LocalStorageService } from '../../../services/storage-service/local-storage.service';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzFormModule } from 'ng-zorro-antd/form';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { NzInputModule } from 'ng-zorro-antd/input';
import { NzLayoutModule } from 'ng-zorro-antd/layout';
import { NzMenuModule } from 'ng-zorro-antd/menu';
import { NzNotificationModule } from 'ng-zorro-antd/notification';
import { NzSpinModule } from 'ng-zorro-antd/spin';
import { NzUploadModule, NzUploadFile } from 'ng-zorro-antd/upload';

@Component({
  selector: 'app-update-product',
  templateUrl: './update-product.component.html',
  imports: [
    CommonModule,
    NzLayoutModule,
    NzButtonModule,
    NzSpinModule,
    NzFormModule,
    NzInputModule,
    ReactiveFormsModule,
    NzNotificationModule,
    NzMenuModule,
    NzIconModule,
    NzUploadModule
  ],
  styleUrls: ['./update-product.component.css']
})
export class UpdateProductComponent implements OnInit {
  id!: number;
  product: any;
  navbarOpen: boolean = false;
  updateProductForm!: FormGroup;
  imagePreview!: string | ArrayBuffer | null;
  selectedFile!: Blob;
  existingImage!: null;
  imgChanged: boolean = false;

  constructor(
    private adminService: AdminService,
    private localstorageservice:LocalStorageService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private fb: FormBuilder,
    
  ) { }

  ngOnInit() {
    // Capture the product ID from the URL parameters in ngOnInit
    this.id = this.activatedRoute.snapshot.params['id'];
    this.getProductById();

    // Initialize the form
    this.updateProductForm = this.fb.group({
      name: [null, [Validators.required]],
      description: [null, [Validators.required]],
      price: [null, [Validators.required]],
      categoryId: [null, [Validators.required]],
      image: [null]
    });
  }

  getProductById() {
    this.adminService.getproductById(this.id).subscribe(
      (res: any) => {
        this.product = res;
        console.log('Product details:', this.product);

        // Populate the form with product details
        this.updateProductForm.patchValue({
          name: this.product.name,
          description: this.product.description,
          price: this.product.price,
          categoryId: this.product.categoryId
        });

        // Handle existing image
        this.existingImage = this.product.image;
      },
      (error: any) => {
        console.error('Error fetching product details:', error);
      }
    );
  }

  beforeUpload = (file: NzUploadFile): boolean => {
    // Perform any necessary checks before uploading the file
    this.selectedFile = file as unknown as Blob;
    this.previewImage();
    this.imgChanged = true;
    return false;
  };

  previewImage() {
    const reader = new FileReader();
    reader.onload = () => {
      this.imagePreview = reader.result;
    };
    reader.readAsDataURL(this.selectedFile);
  }

  updateProduct() {
    if (this.updateProductForm.valid) {
      const formData = new FormData();
      formData.append('name', this.updateProductForm.get('name')?.value);
      formData.append('description', this.updateProductForm.get('description')?.value);
      formData.append('price', this.updateProductForm.get('price')?.value);
      formData.append('categoryId', this.updateProductForm.get('categoryId')?.value);
  
      if (this.imgChanged && this.selectedFile) {
        formData.append('images', this.selectedFile);
      }
  
      this.adminService.updateProduct(this.id, formData).subscribe(
        (res: any) => {
          alert("Product updated Successfully");
          console.log('Product updated successfully:', res);
          this.router.navigate(['/admin/dashboard']);
        },
        (error: any) => {
          console.error('Error updating product:', error);
        }
      );
    }
  }
  

  navigateToAdminDashboard() {
    this.router.navigate(['/admin/dashboard']);
  }

  navigateToAdminCategory() {
    this.router.navigate(['/admin/category']);
  }

  logout() {
    this.localstorageservice.signOut();
    alert("Logout successfully");
    this.router.navigateByUrl("/login");
  }

  navigateToProduct() {
    this.router.navigate(['/admin/product']);
  }
}
