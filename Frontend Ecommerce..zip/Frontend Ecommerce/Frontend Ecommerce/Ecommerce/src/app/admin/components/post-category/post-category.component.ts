import { Component } from '@angular/core';
import { NzLayoutModule } from 'ng-zorro-antd/layout'; // Import Layout module
import { NzButtonModule } from 'ng-zorro-antd/button'; // Import Button module
import { CommonModule } from '@angular/common'; // Import CommonModule
import { NzSpinModule } from 'ng-zorro-antd/spin'; // Import Spin module
import { NzFormModule } from 'ng-zorro-antd/form'; // Import Form module
import { NzInputModule } from 'ng-zorro-antd/input'; // Import Input module
import { AdminService } from '../../admin-service/admin.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms'; // Import ReactiveFormsModule
import { HttpHeaders } from '@angular/common/http'; // Import HttpHeaders
import { LocalStorageService } from '../../../services/storage-service/local-storage.service'; // Import LocalStorageService
import { Router } from '@angular/router';
import { AlertService } from '../../alert-service';

@Component({
  selector: 'app-post-category',
  standalone:true,
  imports: [
    CommonModule,
    NzLayoutModule,
    NzButtonModule,
    NzSpinModule, // Add Spin module
    NzFormModule, // Add Form module
    NzInputModule, // Add Input module
    ReactiveFormsModule // Add ReactiveFormsModule
  ],
  templateUrl: './post-category.component.html',
  styleUrls: ['./post-category.component.css']
})
export class PostCategoryComponent {
  isSpinning: boolean = false;
  categoryForm!: FormGroup;
  notification: any;
// productForm: FormGroup<any>;

  constructor(
    private adminService: AdminService,
    private alert:AlertService,
    private fb: FormBuilder,
    private localStorageService: LocalStorageService,
    private router: Router // Inject LocalStorageService
  ) {}

  ngOnInit() {
    this.categoryForm = this.fb.group({
      name: [null, [Validators.required]],
      description: [null, [Validators.required]],
    });
  }

  navbarOpen = false;
  large: string = 'large'; // Initialize large properly
  
  navigateToAdminDashboard() {
    this.router.navigate(['/admin/dashboard']);
  }

  navigateToAdminCategory() {
    this.router.navigate(['/admin/category']);
  }

  logout() {
    this.localStorageService.signOut();
    alert("Logout successfully");
    this.router.navigateByUrl("/login");
  }

  navigateToProduct() {
    this.router.navigate(['/admin/product']);
  }

  postCategory() {
    if (this.categoryForm.invalid) {
      console.log("Form is invalid");
      return;
    }
    this.isSpinning = true; // Show loading spinner
    const token = this.localStorageService.getToken();
    const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);

    this.adminService.postCategory(this.categoryForm.value, { headers }).subscribe(
      (res) => {
        console.log(res);
        alert("Category posted Successfully");
        // this.alert.showAlert('Product posted Successfully');
        this.router.navigate(['/admin/dashboard']);
      },
      (error) => {
        this.isSpinning = false; // Hide loading spinner
        if (error.status === 400) {
          const errorMessage = error.error.message || "Bad Request: Enter Proper Input";
          console.error(errorMessage, error);
        } else {
          console.error("Error:", error);
        }
      }
    );
    
  }
}
