import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations'; // Import this module
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms'; // Added FormsModule

// NgZorro modules
import { NzUploadModule } from 'ng-zorro-antd/upload';
import { NZ_ICONS, NzIconModule } from 'ng-zorro-antd/icon';
import { NzLayoutModule } from 'ng-zorro-antd/layout';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzNotificationModule } from 'ng-zorro-antd/notification';
import { NzFormModule } from 'ng-zorro-antd/form';
import { NzMessageModule } from 'ng-zorro-antd/message';
import { NzSpinModule } from 'ng-zorro-antd/spin';
import { NzInputModule } from 'ng-zorro-antd/input';
import { NzGridModule } from 'ng-zorro-antd/grid';
import { NzSelectModule } from 'ng-zorro-antd/select'; // Added NzSelectModule
import { NzMenuModule } from 'ng-zorro-antd/menu'; // Added NzMenuModule

// Icons
import { UserOutline, LockOutline } from '@ant-design/icons-angular/icons'; // Use the correct icon names

// Application modules
import { AdminModule } from './admin/admin.module';
import { UserModule } from './user/user.module';
import { AdminRoutingModule } from './admin/admin-routing.module';

// Components
import { AppComponent } from './app.component';
import { OrderComponent } from './user/components/order/order.component'; // Added OrderComponent
import { NavbarComponent } from './components/navbar/navbar.component'; // Added NavbarComponent

const icons = [UserOutline, LockOutline];

@NgModule({
  declarations: [
   
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule, // Import this module
    HttpClientModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule, // Added FormsModule
    NzIconModule,
    NzLayoutModule,
    NzButtonModule,
    NzUploadModule,
    NzNotificationModule, // Import this module
    NzFormModule,
    NzMessageModule,
    NzSpinModule,
    NzInputModule,
    NzGridModule,
    NzSelectModule, // Added NzSelectModule
    NzMenuModule, // Added NzMenuModule
    AdminModule, // Ensure modules are imported
    UserModule,
    AdminRoutingModule,
    AppComponent,
    OrderComponent, 
    NavbarComponent 
  ],
  providers: [
    { provide: NZ_ICONS, useValue: icons }
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  // bootstrap: [AppComponent] // Uncommented bootstrap
})
export class AppModule { }
