import { Injectable, Inject, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';

const USERID = 'userId';
const USERROLE = 'userRole';
const TOKEN = 'token';

@Injectable({
  providedIn: 'root'
})
export class LocalStorageService {
  constructor(@Inject(PLATFORM_ID) private platformId: Object) {}

  saveUserId(userId: string): void {
    if (isPlatformBrowser(this.platformId)) {
      window.localStorage.removeItem(USERID);
      window.localStorage.setItem(USERID, userId);
    }
  }

  saveUserRole(role: string): void {
    if (isPlatformBrowser(this.platformId)) {
      window.localStorage.removeItem(USERROLE);
      window.localStorage.setItem(USERROLE, role);
    }
  }

  saveToken(token: string): void {
    if (isPlatformBrowser(this.platformId)) {
      window.localStorage.removeItem(TOKEN);
      window.localStorage.setItem(TOKEN, token);
    }
  }

  getUserId(): string | null {
    if (isPlatformBrowser(this.platformId)) {
      return window.localStorage.getItem(USERID);
    }
    return null;
  }

  getUserRole(): string | null {
    if (isPlatformBrowser(this.platformId)) {
      return window.localStorage.getItem(USERROLE);
    }
    return null;
  }

  getToken(): string | null {
    if (isPlatformBrowser(this.platformId)) {
      return window.localStorage.getItem(TOKEN);
    }
    return null;
  }

  clear(): void {
    if (isPlatformBrowser(this.platformId)) {
      window.localStorage.clear();
    }
  }

  isUserLoggedIn(): boolean {
    if (isPlatformBrowser(this.platformId)) {
      const token = this.getToken();
      if (token === null) {
        return false;
      }
      const role: string | null = this.getUserRole();
      return role === 'USER';
    }
    return false;
  }

  isAdminLoggedIn(): boolean {
    if (isPlatformBrowser(this.platformId)) {
      const token = this.getToken();
      if (token === null) {
        return false;
      }
      const role: string | null = this.getUserRole();
      return role === 'ADMIN';
    }
    return false;
  }

  signOut(): void {
    if (isPlatformBrowser(this.platformId)) {
      window.localStorage.removeItem(TOKEN);
      window.localStorage.removeItem(USERID);
      window.localStorage.removeItem(USERROLE);
    }
  }

  user(): any {
    if (isPlatformBrowser(this.platformId)) {
      const userId = this.getItem(USERID);
      return userId ? JSON.parse(userId) : null;
    }
    return null;
  }

  getItem(key: string): string | null {
    if (isPlatformBrowser(this.platformId)) {
      return window.localStorage.getItem(key);
    }
    return null;
  }
}