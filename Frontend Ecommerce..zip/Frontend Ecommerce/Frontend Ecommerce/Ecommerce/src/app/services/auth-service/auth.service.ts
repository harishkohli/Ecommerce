import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
import { map, Observable, tap } from 'rxjs';
import { environment } from '../../../environments/environments';
import { LocalStorageService } from '../storage-service/local-storage.service'; // Import LocalStorageService

const BASIC_URL = environment["BASIC_URL"];
export const AUTH_HEADER = "Authorization";

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private http: HttpClient, private storageService: LocalStorageService) { }

  register(signupDTO: any, options: { headers: HttpHeaders }): Observable<any> {
    return this.http.post<any>(`${BASIC_URL}register`, signupDTO, options);
  }

  login(authenticationRequest: any, options: { headers: HttpHeaders }): Observable<any> 
  {
    return this.http.post<any>(`${BASIC_URL}Login`, authenticationRequest, { ...options, observe: 'response' })
      .pipe(
        tap(() => console.log("Login Successful! Welcome Back")),
        tap((res: HttpResponse<any>) => console.log('Response:', res)), // Log the full response
        map((res: HttpResponse<any>) => {
          const authHeader = res.headers.get(AUTH_HEADER);
          if (authHeader) {
            const bearerToken = authHeader.startsWith("Bearer ") ? authHeader.substring(7) : authHeader;
            this.storageService.saveToken(bearerToken);
          } else {
            throw new Error("Authorization header is missing");
          }

          // Log the body to see its structure
          console.log('Response Body:', res.body);

          // Ensure to access the correct properties
          this.storageService.saveUserId(res.body?.userId);
          this.storageService.saveUserRole(res.body?.role);
        })
      );
  }


  log(message: string): void {
    console.log(`User Auth Service: ${message}`)
  }
}
