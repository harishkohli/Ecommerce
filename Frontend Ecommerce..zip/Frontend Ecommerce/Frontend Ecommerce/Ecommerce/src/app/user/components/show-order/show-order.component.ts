import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../../service/customer.service';
import { CommonModule } from '@angular/common';
import { LocalStorageService } from '../../../services/storage-service/local-storage.service';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzFormModule } from 'ng-zorro-antd/form';
import { NzInputModule } from 'ng-zorro-antd/input';
import { NzSelectModule } from 'ng-zorro-antd/select';
import { NzSpinModule } from 'ng-zorro-antd/spin';
import { NzLayoutModule } from 'ng-zorro-antd/layout';
import { Router } from '@angular/router';
@Component({
  selector: 'app-show-order',
  templateUrl: './show-order.component.html',
  imports: [CommonModule,
    ReactiveFormsModule,

    FormsModule,
    NzLayoutModule,
    NzSpinModule,
    NzFormModule,
    NzInputModule,
    NzSelectModule,
    NzButtonModule
  ],
  styleUrls: ['./show-order.component.css'],

})
export class ShowOrderComponent implements OnInit {
  orders: any[] = [];
  navbarOpen: any;

  constructor(private customerService: CustomerService, private localstorage: LocalStorageService, private router: Router) { }

  ngOnInit(): void {
    this.getOrders();
    if (this.localstorage.getToken()) {
      this.getOrders();
    } else {
      this.router.navigate(['/login']);
    }
  }

  getOrders(): void {
    const userId = Number(this.localstorage.getUserId());
    const token = this.localstorage.getToken();
    this.customerService.getOrdersByUserId(userId).subscribe(
      (data: any[]) => {
        this.orders = data;
        console.log(this.orders);
      },
      (error: any) => {
        console.error('Error fetching orders', error);
      }
    );
  }

  deleteOrder(orderId: number): void {
    this.customerService.deleteOrder(orderId).subscribe(
      (response: any) => {
        this.getOrders(); // Refresh the order list
        alert("Order cancelled");
        this.router.navigate(['/user/dashboard']);

      },
      (error: any) => {
        console.error('Error deleting order', error);
      }
    );
  }

  logout() {
    this.localstorage.signOut();
    alert("Logout successfully");
    this.router.navigate(['/login']);
  }

  navigateToLogin() {
    this.router.navigate(['/login']);
  }

  navigateToSignUp() {
    this.router.navigate(['/register']);
  }

  navigateToUserDashboard() {
    this.router.navigate(['/user/dashboard']);
  }

  gotocart() {
    this.router.navigate(['/user/cart']);
  }
  displayOrders() {
    this.router.navigate(['/user/orders']);
  }
}