import { Component, OnInit } from '@angular/core';
import { LocalStorageService } from '../../../services/storage-service/local-storage.service';
import { NzLayoutModule } from 'ng-zorro-antd/layout';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { CustomerService } from '../../service/customer.service';
import { NzGridModule } from 'ng-zorro-antd/grid';
import { NzSizeLDSType } from 'ng-zorro-antd/core/types';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms'; // Import ReactiveFormsModule
import { FormsModule } from '@angular/forms';

interface Product {
  id: number;
  name: string;
  description: string;
  price: number;
  categoryName: string;
  processedImage: string;
  returnedImage: string;
}

@Component({
  selector: 'app-dashboard',
  imports: [
    CommonModule,
    NzLayoutModule,
    NzButtonModule,
    NzGridModule,
    ReactiveFormsModule,
    FormsModule
  ],
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'] // Correct 'styleUrls'
})
export class DashboardComponent implements OnInit {

  navbarOpen: any;
  products: Product[] = [];
  primary!: NzSizeLDSType;
  large!: NzSizeLDSType;
  searchForm!:FormGroup;

  constructor(
    private router: Router,
    private localStorageService: LocalStorageService,
    private service: CustomerService,
    private fb:FormBuilder
  ) {}


  displayOrders() {
    this.router.navigate(['/user/orders']);
    }
  logout() {
    this.localStorageService.signOut();
    alert("Logout successfully");
    this.router.navigateByUrl("/login");
  }

  navigateToLogin() {
    this.router.navigate(['/login']);
  }

  navigateToSignUp() {
    this.router.navigate(['/register']);
  }

  navigateToUserDashboard() {
    this.router.navigate(['/user/dashboard']);
  }




  ngOnInit() {
    this.searchForm=this.fb.group({
       title:[null]
    })
    this.getAllProducts();
  }

  getAllProducts() {
    this.service.getAllProducts().subscribe((res: Product[]) => {
      console.log(res); // Should be an array of products
      res.forEach((element: Product) => {
        element.processedImage = "data:image/jpeg;base64," + element.returnedImage;
        this.products.push(element);
      });
    });
  }

  searchProduct() {
    const searchTerm = this.searchForm.get('title')?.value;
    if (searchTerm) {
      this.service.searchProductByTitle(searchTerm).subscribe((res: Product[]) => {
        this.products = res.map((product: Product) => {
          product.processedImage = 'data:image/jpeg;base64,' + product.returnedImage;
          console.log(this.products);
          return product;
        });
      });
    }
  }
  gotocart()
  {
    this.router.navigate(['/user/cart']);
  }
  addToCart(product: Product) {
    const userIdStr = this.localStorageService.getUserId(); // Assuming you have a method to get the user ID
    if (userIdStr) {
      const userId = Number(userIdStr); // Convert string to number
      const cartDTO = {
        userId: userId,
        productId: product.id,
        quantity: 1,
        price: product.price
      };
      this.service.addProductToCart(cartDTO).subscribe((res) => {
        alert("Product added to cart");
        console.log('Product added to cart', res);
      });
    } else {
      alert("User ID is null");
      console.error('User ID is null');
    }
  }
}
