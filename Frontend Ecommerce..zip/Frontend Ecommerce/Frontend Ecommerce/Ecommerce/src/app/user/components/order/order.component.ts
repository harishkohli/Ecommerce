import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzFormModule } from 'ng-zorro-antd/form';
import { NzInputModule } from 'ng-zorro-antd/input';
import { NzSelectModule } from 'ng-zorro-antd/select';
import { NzSpinModule } from 'ng-zorro-antd/spin';
import { LocalStorageService } from '../../../services/storage-service/local-storage.service';
import { NzLayoutModule } from 'ng-zorro-antd/layout';
import { Router } from '@angular/router';
import { NzNotificationService } from 'ng-zorro-antd/notification';
import { CustomerService } from '../../service/customer.service'; // Import the service

@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.css'],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    NzLayoutModule,
    NzSpinModule,
    NzFormModule,
    NzInputModule,
    NzSelectModule,
    NzButtonModule
  ],
})
export class OrderComponent implements OnInit {
  isspinning: boolean = false;
  validateForm!: FormGroup;
  Payment: string[] = ['Credit Card', 'Debit Card', 'Cash On Delivery']; // Example payment methods
  
  navbarOpen: any;

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private notification: NzNotificationService,
    private service: CustomerService, // Inject the service
    private localstorage:LocalStorageService
  ) {}

  ngOnInit() {
    this.validateForm = this.fb.group({
      address: [null, Validators.required],
      orderDescription: [null, Validators.required],
      payment: [null, Validators.required]
    });
  }

  displayOrders() {
    this.router.navigate(['/user/orders']);
    }
  placeOrder(): void {
    this.isspinning = true;
    console.log(this.validateForm.value);
    this.service.placeOrder(this.validateForm.value).subscribe(
      (res: any) => {
       
        console.log('Your order is successfully placed', res);
        this.isspinning = false;
        alert("Order Placed Successfully");
        this.router.navigate(['/user/orders']);
      },
      (error: any) => {
        console.error('Error placing order:', error);
        this.isspinning = false;
        alert("Error in placing order");
        
      }
    );
  }
  
  logout() {
    this.localstorage.signOut();
    alert("Logout successfully");
    this.router.navigateByUrl("/login");
  }

  navigateToLogin() {
    this.router.navigate(['/login']);
  }

  navigateToSignUp() {
    this.router.navigate(['/register']);
  }

  navigateToUserDashboard() {
    this.router.navigate(['/user/dashboard']);
  }

  gotocart() {
    this.router.navigate(['/user/cart']);
  }
}
