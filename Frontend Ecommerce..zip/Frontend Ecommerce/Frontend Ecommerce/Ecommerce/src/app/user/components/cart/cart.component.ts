import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../../service/customer.service';
import { LocalStorageService } from '../../../services/storage-service/local-storage.service';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzGridModule } from 'ng-zorro-antd/grid';
import { NzLayoutModule } from 'ng-zorro-antd/layout';
import { Router } from '@angular/router';

interface CartItem {
  productId: number;
  productName: string;
  quantity: number;
  price: number;
}

@Component({
  selector: 'app-cart',
  standalone: true,
  imports: [
    CommonModule,
        NzLayoutModule,
        NzButtonModule,
        NzGridModule,
        ReactiveFormsModule,
        FormsModule
  ],
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  cartItems: CartItem[] = [];
navbarOpen: any;
  totalAmount!: number;

  constructor(
    private service: CustomerService,
    private localStorageService: LocalStorageService,
    private router: Router
  ) {}
  displayOrders() {
    this.router.navigate(['/user/orders']);
    }
  
  logout() {
    this.localStorageService.signOut();
    alert("Logout successfully");
    this.router.navigateByUrl("/login");
  }

  navigateToLogin() {
    this.router.navigate(['/login']);
  }

  navigateToSignUp() {
    this.router.navigate(['/register']);
  }

  navigateToUserDashboard() {
    this.router.navigate(['/user/dashboard']);
  }

  ngOnInit() {
    this.getCartItems();
  }
  gotocart()
  {
    this.router.navigate(['/user/cart']);
  }
  getCartItems() {
    const userIdStr = this.localStorageService.getUserId();
    if (userIdStr) {
      const userId = Number(userIdStr);
      this.service.getCartByUserId(userId).subscribe((orderDTO: any) => {
        this.cartItems = orderDTO.cartDTO.map((item: any) => ({
          productId: item.productId,
          productName: item.productName,
          quantity: item.quantity,
          price: item.price
        }));
        this.calculateTotalAmount();
      });
    } else {
      alert("User ID is null");
      console.error('User ID is null');
    }
  }

  calculateTotalAmount() {
    this.totalAmount = this.cartItems.reduce((total, item) => total + (item.price * item.quantity), 0);
  }

  updateQuantity(productId: number, action: 'add' | 'deduct') {
    const userIdStr = this.localStorageService.getUserId();
    if (userIdStr) {
      const userId = Number(userIdStr);
      this.service.updateQuantity(userId, productId, action).subscribe((res) => {
        console.log('Quantity updated', res);
        this.getCartItems();
      });
    } else {
      alert("User ID is null");
      console.error('User ID is null');
    }
  }
  increaseQuantity(productId: number) {
    this.updateQuantity(productId, 'add');
  }

  decreaseQuantity(productId: number) {
    this.updateQuantity(productId, 'deduct');
  }

  placeOrder() {
    this.router.navigate(['/user/order']);
  }
}
