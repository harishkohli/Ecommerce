import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CustomerService } from '../../../src/app/user/service/customer.service';
import { LocalStorageService } from '../../../src/app/services/storage-service/local-storage.service';
import { UserRoutingModule } from './user-routing.module';
import { CartComponent } from './components/cart/cart.component';

@NgModule({
  declarations: [
    // other components
  ],
  imports: [
    CommonModule, // Import CommonModule here
    FormsModule,
    ReactiveFormsModule,
    UserRoutingModule,
    CartComponent // Import CartComponent here
    // other modules
  ],
  providers: [
    CustomerService,
    LocalStorageService,
    // other providers
  ],
  exports: [
    CartComponent,
    // other components
  ]
})
export class UserModule { }
