import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { LocalStorageService } from '../../services/storage-service/local-storage.service';

const baseUrl = 'http://localhost:8080/api/customer'; 
const baseUrl1 = 'http://localhost:8080/api'; 
const baseUrl2 = 'http://localhost:8080/api/product/search'; 

@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  constructor(private http: HttpClient, private localStorageService: LocalStorageService) {}

  getAllProducts(): Observable<any> {
    const headers = this.createAuthorizationHeader();
    return this.http.get<any[]>(`${baseUrl}/products`, { headers });
  }
  getAllProductsfornavbar(headers?: { headers: HttpHeaders }): Observable<any> {
    return this.http.get<any[]>(`${baseUrl1}/products`, headers);
  }

  searchProductByTitle(title: string): Observable<any> {
    const headers = this.createAuthorizationHeader();
    return this.http.get<any[]>(`${baseUrl}/product/search/${title}`, { headers });
  }

  searchProductByTitleforNavbar(title: string): Observable<any> {
    const token = this.localStorageService.getToken();
    let headers = new HttpHeaders();
  
    if (token) {
      headers = headers.set('Authorization', `Bearer ${token}`);
    }
  
    return this.http.get<any[]>(`${baseUrl2}/${title}`, { headers });
  }

  addProductToCart(cartDTO: any): Observable<any> {
    const headers = this.createAuthorizationHeader();
    return this.http.post<any>(`${baseUrl}/cart`, cartDTO, { headers });
  }

  updateQuantity(userId: number, productId: number, action: 'add' | 'deduct'): Observable<any> {
    const headers = this.createAuthorizationHeader();
    return this.http.get<any>(`${baseUrl}/cart/${userId}/${action}/${productId}`, { headers });
  }
 
  
  createAuthorizationHeader(): HttpHeaders {
    const token = this.localStorageService.getToken();
    return new HttpHeaders().set('Authorization', `Bearer ${token}`);
  }

  getCartByUserId(userId: number): Observable<any> 
  {
    const headers = this.createAuthorizationHeader();
    return this.http.get<any>(`${baseUrl}/cart/${userId}`, { headers });
  }

  placeOrder(placeOrderDTO: any): Observable<any> {
    placeOrderDTO.userId = this.localStorageService.getUserId();
    const headers = this.createAuthorizationHeader();
    return this.http.post<any>(`${baseUrl}/placeOrder`, placeOrderDTO, { headers, responseType: 'text' as 'json' });
}

getOrdersByUserId(userId: number): Observable<any> {
  const headers = this.createAuthorizationHeader();
  return this.http.get<any[]>(`${baseUrl}/orders/${userId}`, { headers });
}

deleteOrder(orderId: number): Observable<any> {
  const headers = this.createAuthorizationHeader();
  return this.http.delete(`${baseUrl}/CancelOrder/${orderId}`, { headers, responseType: 'text' as 'json' });
}

}
