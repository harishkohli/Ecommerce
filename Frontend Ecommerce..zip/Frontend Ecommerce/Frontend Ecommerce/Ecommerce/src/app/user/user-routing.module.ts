import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { userGuard } from '../guards/user-guard/user.guard'; // Correct guard name
import { CartComponent } from './components/cart/cart.component';
import { OrderComponent } from './components/order/order.component';
import { ShowOrderComponent } from './components/show-order/show-order.component';

const routes: Routes = [
  { path: "dashboard", component: DashboardComponent, canActivate: [userGuard] },
  { path: "cart", component: CartComponent, canActivate: [userGuard] },
  { path: "order", component: OrderComponent, canActivate: [userGuard] },
  { path: "orders", component: ShowOrderComponent, canActivate: [userGuard] }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UserRoutingModule { }
