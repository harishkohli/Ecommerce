import { inject, Injectable } from '@angular/core';
import { CanActivateFn, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { NzNotificationService } from 'ng-zorro-antd/notification';
import { LocalStorageService } from '../../services/storage-service/local-storage.service';

export const userGuard: CanActivateFn = (route: ActivatedRouteSnapshot, state: RouterStateSnapshot) => {
  const router = inject(Router);
  const notification = inject(NzNotificationService);
  const localStorageService = inject(LocalStorageService);

  if (localStorageService.isAdminLoggedIn()) {
    router.navigateByUrl('/admin/dashboard');
    notification.error("Error", "You don't have access to this page", { nzDuration: 5000 });
    return false;
  } else if (!localStorageService.getToken()) {
    localStorageService.signOut();
    router.navigateByUrl('/login');
    notification.error("Error", "You are not logged in. Please login first", { nzDuration: 5000 });
    return false;
  }
  return true;
};
