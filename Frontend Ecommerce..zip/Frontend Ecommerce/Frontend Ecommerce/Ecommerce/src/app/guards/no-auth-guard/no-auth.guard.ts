import { CanActivateFn, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { inject } from '@angular/core';
import { LocalStorageService } from '../../services/storage-service/local-storage.service';
import { NzNotificationService } from 'ng-zorro-antd/notification';

export const noAuthGuard: CanActivateFn = (route: ActivatedRouteSnapshot, state: RouterStateSnapshot) => {
  const router = inject(Router);
  const notification = inject(NzNotificationService);
  const localStorageService = inject(LocalStorageService);

  if (localStorageService.getToken() && localStorageService.isUserLoggedIn()) {
    router.navigateByUrl('/user/dashboard');
    notification.error('ERROR', "You don't have access to this page.", { nzDuration: 5000 });
    return false;
  } else if (!localStorageService.getToken()) {
    LocalStorageService.signOut();
    router.navigateByUrl('/login');
    notification.error('ERROR', "You are not logged in. Please login first.", { nzDuration: 5000 });
    return false;
  }
  return true;
};
