import { Component } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { NzFormModule } from 'ng-zorro-antd/form';
import { NzInputModule } from 'ng-zorro-antd/input';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzSpinModule } from 'ng-zorro-antd/spin';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../services/auth-service/auth.service';
import { HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    NzFormModule,
    NzInputModule,
    NzButtonModule,
    NzSpinModule,
  ],
  providers: [AuthService]
})
export class RegisterComponent {
  validateForm!: FormGroup;
  isSpinning = false;

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router // Inject Router
  ) {
    this.validateForm = this.fb.group({
      name: [null, [Validators.required]],
      email: [null, [Validators.required, Validators.email]],
      password: [null, [Validators.required]],
      confirmPassword: [null, [Validators.required, this.confirmationValidator]]
    });
  }

  confirmationValidator = (control: FormControl): { [s: string]: boolean } => {
    if (!control.value) {
      return { required: true };
    } else if (control.value !== this.validateForm.controls['password'].value) {
      return { confirm: true, error: true };
    }
    return {};
  }

  navigateToLogin() {
    this.router.navigate(['/login']);
  }


  register() {
    this.isSpinning = true;
    this.authService.register(this.validateForm.value,
      { headers: new HttpHeaders().set('Content-Type', 'application/json') })
      .subscribe(
        (res: any) => {
          this.isSpinning = false;
          console.log(res);
          alert("Registration successful");
          this.router.navigateByUrl('/login');
        },
        (error: any) => {
          this.isSpinning = false;
          console.error('Registration error', error);
          alert("Registration error");
          if (error.status === 403) {
            alert('Forbidden: You do not have permission to access this resource.');
          }
        }
      );
  }

}
