import { Component, OnInit } from '@angular/core';
import { LocalStorageService } from '../../services/storage-service/local-storage.service';
import { NzLayoutModule } from 'ng-zorro-antd/layout';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { CommonModule, NgClass } from '@angular/common';
import { Router } from '@angular/router';
import { CustomerService } from '../../user/service/customer.service'; // Updated import
import { NzGridModule } from 'ng-zorro-antd/grid';
import { NzSizeLDSType } from 'ng-zorro-antd/core/types';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms'; // Import FormBuilder
import { FormsModule } from '@angular/forms'; // Import FormsModule
import { NzFormModule } from 'ng-zorro-antd/form'; // Import NzFormModule
import { NzInputModule } from 'ng-zorro-antd/input'; // Import NzInputModule
import { HttpHeaders } from '@angular/common/http';

interface Product {
  id: number;
  name: string;
  description: string;
  price: number;
  categoryName: string;
  processedImage: string;
  returnedImage: string;
}

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css'],
  standalone: true,
  imports: [
    CommonModule,
    NzLayoutModule,
    NzButtonModule,
    NzGridModule,
    ReactiveFormsModule, // Add ReactiveFormsModule
    FormsModule, // Add FormsModule
    NzFormModule, // Add NzFormModule
    NzInputModule, // Add NzInputModule
    NgClass
  ]
})
export class NavbarComponent implements OnInit {
  isUserLoggedIn: boolean = false;
  isAdminLoggedIn: boolean = false;
  navbarOpen = false;
  products: Product[] = [];
  primary!: NzSizeLDSType;
  large!: NzSizeLDSType;
  searchForm!: FormGroup;
  
  constructor(
    private router: Router, 
    private localStorageService: LocalStorageService,
    private service: CustomerService, // Updated service
    private fb: FormBuilder // FormBuilder for form control
  ) {}

  ngOnInit(): void {
    this.updateLoginStatus();
    this.router.events.subscribe((event: { constructor: { name: string; }; }) => {
      if (event.constructor.name === "NavigationEnd") {
        this.updateLoginStatus();
      }
    });
    this.searchForm = this.fb.group({
      title: [null]
    });
    this.getAllProducts(); // Ensure this method is called
  }

  updateLoginStatus() {
    this.isUserLoggedIn = this.localStorageService.isUserLoggedIn();
    this.isAdminLoggedIn = this.localStorageService.isAdminLoggedIn();
  }

  logout() {
    this.localStorageService.signOut();
    alert("Logout successfully");
    this.router.navigateByUrl("/login");
  }

  navigateToLogin() {
    this.router.navigate(['/login']);
  }


  navigateToSignUp() {
    this.router.navigate(['/register']);
  }

  navigateToAdminDashboard() {
    this.router.navigate(['/admin/dashboard']);
  }

  navigateToUserDashboard() {
    this.router.navigate(['/user/dashboard']);
  }

  searchProduct() {
    const searchTerm = this.searchForm.get('title')?.value;
    if (searchTerm == null) {
      this.router.navigate(['/user/dashboard']);
    }
    if (searchTerm) {
      this.service.searchProductByTitleforNavbar(searchTerm).subscribe((res: Product[]) => {
        this.products = res.map((product: Product) => {
          product.processedImage = 'data:image/jpeg;base64,' + product.returnedImage;
          console.log(this.products);
          return product;
        });
      }, (error) => {
        console.error('Failed to search products:', error); // Log the error
      });
    }
  }
  gotocart() {
    this.router.navigate(['/user/cart']);
  }

  addToCart() {
    this.router.navigate(['/register']);
  }

  getAllProducts() {
    const token = this.localStorageService.getToken();
    let headers = new HttpHeaders();
  
    if (token) {
      console.log('Token:', token); // Log the token
      headers = headers.set('Authorization', `Bearer ${token}`);
    }
  
    this.service.getAllProductsfornavbar({ headers }).subscribe((res: Product[]) => {
      // console.log('Products fetched:', res); // Log the fetched products
      res.forEach((element: Product) => {
        element.processedImage = "data:image/jpeg;base64," + element.returnedImage;
        this.products.push(element);
      });
      // console.log('Products array:', this.products); // Log the products array
    }, (error) => {
      console.error('Failed to fetch products:', error); // Log the error
    });
  }
}
