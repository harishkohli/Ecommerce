import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { NzFormModule } from 'ng-zorro-antd/form';
import { NzInputModule } from 'ng-zorro-antd/input';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzSpinModule } from 'ng-zorro-antd/spin';
import { NzCheckboxModule } from 'ng-zorro-antd/checkbox';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../services/auth-service/auth.service'; // Adjust the path to your service
import { HttpHeaders } from '@angular/common/http';
import { LocalStorageService } from '../../services/storage-service/local-storage.service';
import { Router } from '@angular/router'; // Correct import
import { NzNotificationService } from 'ng-zorro-antd/notification';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    NzFormModule,
    NzInputModule,
    NzButtonModule,
    NzSpinModule,
    NzCheckboxModule
  ],
  providers: [AuthService]
})
export class LoginComponent {
  validateForm!: FormGroup;
  isSpinning = false;

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router,
    private notification: NzNotificationService,
    private localStorageService: LocalStorageService
  ) {
    this.validateForm = this.fb.group({
      username: [null, [Validators.required]],
      password: [null, [Validators.required]],
      remember: [true]
    });
  }

  login() {
    this.isSpinning = true;
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    this.authService.login(this.validateForm.value, { headers })
      .subscribe(
        (res: any) => {
          this.isSpinning = false;
          console.log(res);
          alert("Login successful");
          if (this.localStorageService.isAdminLoggedIn()) {
            this.router.navigateByUrl("/admin/dashboard");
            
          } else if (this.localStorageService.isUserLoggedIn()) {
            this.router.navigateByUrl("/user/dashboard");
          }
        },
        (error: any) => {
          this.isSpinning = false;
          console.error(error);
          if (error.status == 406) {
            alert("Error User id is not active Please register first");
            this.notification.error(
              "ERROR", "User is not Active. Please register first.",
              { nzDuration: 5000 }
            );
          } else {
            alert("ERROR Bad Credentials");
            this.notification.error(
              "ERROR", "Bad Credentials",
              { nzDuration: 5000 }
            );
          }
        }
      );
  }
  register()
  {
    this.router.navigateByUrl('/register');
  }
}
