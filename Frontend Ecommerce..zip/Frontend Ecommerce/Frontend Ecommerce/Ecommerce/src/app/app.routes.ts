import { Routes } from '@angular/router';
import { RegisterComponent } from './components/register/register.component';
import { LoginComponent } from './components/login/login.component';// Import LayoutComponent
import { NavbarComponent } from './components/navbar/navbar.component';

export const routes: Routes = [
  {
    path: '',
    children: [
      { path: '',component: NavbarComponent , pathMatch: 'full' },
      { path: 'register', component: RegisterComponent },
      { path: 'login', component: LoginComponent },
      { path: 'admin', loadChildren:()=> import("./admin/admin.module").then(m=>m.AdminModule)},
      { path: 'user', loadChildren:()=> import("./user/user.module").then(m=>m.UserModule)}
    ]
  }
];
