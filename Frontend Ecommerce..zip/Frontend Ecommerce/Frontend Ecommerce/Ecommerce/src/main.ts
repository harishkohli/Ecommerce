import { bootstrapApplication } from '@angular/platform-browser';
import { provideAnimations } from '@angular/platform-browser/animations';
import { provideHttpClient, withFetch } from '@angular/common/http';
import { AppComponent } from './app/app.component';
import { importProvidersFrom } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { provideRouter } from '@angular/router';
import { NzLayoutModule } from 'ng-zorro-antd/layout';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { routes } from './app/app.routes';

bootstrapApplication(AppComponent, {
  providers: [
    provideAnimations(), // Ensure animations are enabled
    provideRouter(routes), 
    importProvidersFrom(BrowserModule), // Import BrowserModule
    importProvidersFrom(NzLayoutModule), // Ensure correct provider import
    importProvidersFrom(NzButtonModule), 
    provideHttpClient(withFetch()) // Use withFetch() for HttpClient
  ]
}).catch(err => console.error(err));