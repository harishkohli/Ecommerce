import {
  NZ_WAVE_GLOBAL_CONFIG,
  NZ_WAVE_GLOBAL_DEFAULT_CONFIG,
  NzWaveDirective,
  NzWaveModule,
  NzWaveRenderer,
  provideNzWave
} from "./chunk-VBSFKJHH.js";
import "./chunk-5LBX6EU6.js";
import "./chunk-KMRU2LBF.js";
import "./chunk-UFIYT4PA.js";
import "./chunk-FD3NGQXN.js";
import "./chunk-7ABNV2KD.js";
import "./chunk-XY3PCWZ3.js";
import "./chunk-EOOAREXX.js";
import "./chunk-OUAVWW6Y.js";
export {
  NZ_WAVE_GLOBAL_CONFIG,
  NZ_WAVE_GLOBAL_DEFAULT_CONFIG,
  NzWaveDirective,
  NzWaveModule,
  NzWaveRenderer,
  provideNzWave
};
