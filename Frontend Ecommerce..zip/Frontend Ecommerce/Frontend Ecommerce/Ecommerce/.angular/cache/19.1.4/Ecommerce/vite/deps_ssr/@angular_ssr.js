import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  AngularAppEngine,
  InlineCriticalCssProcessor,
  PrerenderFallback,
  RenderMode,
  createRequestHandler,
  destroyAngularServerApp,
  extractRoutesAndCreateRouteTree,
  getOrCreateAngularServerApp,
  getRoutesFromAngularRouterConfig,
  provideServerRoutesConfig,
  setAngularAppEngineManifest,
  setAngularAppManifest
} from "./chunk-TDCD7F75.js";
import "./chunk-MSOTWGW6.js";
import "./chunk-YVRLC3EC.js";
import "./chunk-ZHUQH5P4.js";
import "./chunk-ALPVF5BG.js";
import "./chunk-PENRMRG4.js";
import "./chunk-62NU2IYY.js";
import "./chunk-J5O3A5ZH.js";
import "./chunk-IINFVMXG.js";
import "./chunk-GZUVJ63M.js";
import "./chunk-T4XHMJL2.js";
import "./chunk-YHCV7DAQ.js";
export {
  AngularAppEngine,
  PrerenderFallback,
  RenderMode,
  createRequestHandler,
  provideServerRoutesConfig,
  InlineCriticalCssProcessor as ɵInlineCriticalCssProcessor,
  destroyAngularServerApp as ɵdestroyAngularServerApp,
  extractRoutesAndCreateRouteTree as ɵextractRoutesAndCreateRouteTree,
  getOrCreateAngularServerApp as ɵgetOrCreateAngularServerApp,
  getRoutesFromAngularRouterConfig as ɵgetRoutesFromAngularRouterConfig,
  setAngularAppEngineManifest as ɵsetAngularAppEngineManifest,
  setAngularAppManifest as ɵsetAngularAppManifest
};
