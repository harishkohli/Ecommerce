import {
  DEFAULT_TWOTONE_COLOR,
  NZ_ICONS,
  NZ_ICONS_PATCH,
  NZ_ICONS_USED_BY_ZORRO,
  NZ_ICON_DEFAULT_TWOTONE_COLOR,
  NzIconDirective,
  NzIconModule,
  NzIconPatchService,
  NzIconService,
  provideNzIcons,
  provideNzIconsPatch
} from "./chunk-EM2DYGSL.js";
import "./chunk-2MTRCEC6.js";
import "./chunk-UFIYT4PA.js";
import "./chunk-FD3NGQXN.js";
import "./chunk-7ABNV2KD.js";
import "./chunk-IG3F35GS.js";
import "./chunk-XY3PCWZ3.js";
import "./chunk-EOOAREXX.js";
import "./chunk-OUAVWW6Y.js";
export {
  DEFAULT_TWOTONE_COLOR,
  NZ_ICONS,
  NZ_ICONS_PATCH,
  NZ_ICONS_USED_BY_ZORRO,
  NZ_ICON_DEFAULT_TWOTONE_COLOR,
  NzIconDirective,
  NzIconModule,
  NzIconPatchService,
  NzIconService,
  provideNzIcons,
  provideNzIconsPatch
};
