import {
  BrowserAnimationsModule,
  InjectableAnimationEngine,
  NoopAnimationsModule,
  provideAnimations,
  provideNoopAnimations
} from "./chunk-5LBX6EU6.js";
import "./chunk-KMRU2LBF.js";
import "./chunk-UFIYT4PA.js";
import "./chunk-FD3NGQXN.js";
import "./chunk-XY3PCWZ3.js";
import {
  ANIMATION_MODULE_TYPE
} from "./chunk-EOOAREXX.js";
import "./chunk-OUAVWW6Y.js";
export {
  ANIMATION_MODULE_TYPE,
  BrowserAnimationsModule,
  NoopAnimationsModule,
  provideAnimations,
  provideNoopAnimations,
  InjectableAnimationEngine as ɵInjectableAnimationEngine
};
