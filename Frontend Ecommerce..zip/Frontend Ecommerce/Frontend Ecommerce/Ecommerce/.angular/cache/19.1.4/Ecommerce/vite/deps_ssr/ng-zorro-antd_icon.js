import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  DEFAULT_TWOTONE_COLOR,
  NZ_ICONS,
  NZ_ICONS_PATCH,
  NZ_ICONS_USED_BY_ZORRO,
  NZ_ICON_DEFAULT_TWOTONE_COLOR,
  NzIconDirective,
  NzIconModule,
  NzIconPatchService,
  NzIconService,
  provideNzIcons,
  provideNzIconsPatch
} from "./chunk-VTN3VWY5.js";
import "./chunk-5V3QVRMM.js";
import "./chunk-YG2S5WPC.js";
import "./chunk-6OAIRWET.js";
import "./chunk-L3CIX3NK.js";
import "./chunk-62NU2IYY.js";
import "./chunk-J5O3A5ZH.js";
import "./chunk-IINFVMXG.js";
import "./chunk-GZUVJ63M.js";
import "./chunk-T4XHMJL2.js";
import "./chunk-YHCV7DAQ.js";
export {
  DEFAULT_TWOTONE_COLOR,
  NZ_ICONS,
  NZ_ICONS_PATCH,
  NZ_ICONS_USED_BY_ZORRO,
  NZ_ICON_DEFAULT_TWOTONE_COLOR,
  NzIconDirective,
  NzIconModule,
  NzIconPatchService,
  NzIconService,
  provideNzIcons,
  provideNzIconsPatch
};
