import {
  NzTransitionPatchDirective,
  NzTransitionPatchModule
} from "./chunk-LH6WW2JG.js";
import "./chunk-EOOAREXX.js";
import "./chunk-OUAVWW6Y.js";
export {
  NzTransitionPatchDirective as ɵNzTransitionPatchDirective,
  NzTransitionPatchModule as ɵNzTransitionPatchModule
};
