import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  NzTransitionPatchDirective,
  NzTransitionPatchModule
} from "./chunk-ZYVUFXUJ.js";
import "./chunk-GZUVJ63M.js";
import "./chunk-T4XHMJL2.js";
import "./chunk-YHCV7DAQ.js";
export {
  NzTransitionPatchDirective as ɵNzTransitionPatchDirective,
  NzTransitionPatchModule as ɵNzTransitionPatchModule
};
