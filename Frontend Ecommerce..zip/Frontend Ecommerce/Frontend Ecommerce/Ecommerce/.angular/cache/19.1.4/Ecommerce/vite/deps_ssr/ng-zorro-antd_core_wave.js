import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  NZ_WAVE_GLOBAL_CONFIG,
  NZ_WAVE_GLOBAL_DEFAULT_CONFIG,
  NzWaveDirective,
  NzWaveModule,
  NzWaveRenderer,
  provideNzWave
} from "./chunk-5STW6AP7.js";
import "./chunk-YG2S5WPC.js";
import "./chunk-ZHUQH5P4.js";
import "./chunk-ALPVF5BG.js";
import "./chunk-PENRMRG4.js";
import "./chunk-62NU2IYY.js";
import "./chunk-J5O3A5ZH.js";
import "./chunk-IINFVMXG.js";
import "./chunk-GZUVJ63M.js";
import "./chunk-T4XHMJL2.js";
import "./chunk-YHCV7DAQ.js";
export {
  NZ_WAVE_GLOBAL_CONFIG,
  NZ_WAVE_GLOBAL_DEFAULT_CONFIG,
  NzWaveDirective,
  NzWaveModule,
  NzWaveRenderer,
  provideNzWave
};
